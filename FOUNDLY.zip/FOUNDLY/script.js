// زر تسجيل الدخول – ينقلك للصفحة الثانية
const loginButton = document.getElementById('loginBtn');
if (loginButton) {
  loginButton.addEventListener('click', function () {
    window.location.href = 'report.html';
  });
}

// زر إرسال بلاغ – يتحقق من المدخلات
function submitReport() {
  const item = document.getElementById('itemName')?.value;
  const category = document.getElementById('category')?.value;
  const datetime = document.getElementById('datetime')?.value;
  const location = document.getElementById('location')?.value;

  if (item && category && datetime && location) {
    alert("Lost item report submitted successfully!");
  } else {
    alert("Please fill in all required fields.");
  }
}
